package br.com.spotify.model;

public class Musica extends Informacoes {


}
